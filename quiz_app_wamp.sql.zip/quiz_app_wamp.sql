-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 29, 2024 at 04:49 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `quiz_app`
--

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE IF NOT EXISTS `answers` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `answer` varchar(255) NOT NULL,
  `ans_id` int(11) NOT NULL,
  PRIMARY KEY (`aid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=85 ;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`aid`, `answer`, `ans_id`) VALUES
(41, 'Def', 1),
(42, 'function', 1),
(43, ' func', 1),
(44, 'None of these', 1),
(45, '( )', 2),
(46, '[ ]', 2),
(47, '{ }', 2),
(48, 'None of these', 2),
(49, '.py', 3),
(50, '.pl', 3),
(51, '.ty', 3),
(52, 'None of these', 3),
(53, 'Java', 4),
(54, 'C#', 4),
(55, 'C', 4),
(56, 'Perl', 4),
(57, 'string_123', 5),
(58, '_hello', 5),
(59, '12_hello', 5),
(60, 'None of these', 5),
(61, 'False', 6),
(62, 'True', 6),
(63, 'Depends on program', 6),
(64, 'Depends on computer', 6),
(69, 'system.getversion', 7),
(70, 'sys.version(1)', 7),
(71, 'system.get', 7),
(72, 'None of the above', 7),
(73, 'dvd()', 8),
(74, 'ntr()', 8),
(75, 'sqrt()', 8),
(76, 'print()', 8),
(77, 'functionable', 9),
(78, 'mutable', 9),
(79, 'immutable', 9),
(80, 'None of these', 9),
(81, 'define function(x)', 10),
(82, 'function x()', 10),
(83, 'def x():', 10),
(84, 'None of these', 10);

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE IF NOT EXISTS `history` (
  `email` varchar(20) NOT NULL,
  `qid` int(3) NOT NULL,
  `answer` varchar(20) NOT NULL,
  `mark` int(1) NOT NULL,
  `total` int(3) DEFAULT NULL,
  `grade` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`email`, `qid`, `answer`, `mark`, `total`, `grade`) VALUES
('ramjoker1208@gmail.c', 1, 'Sherlock Holmes', 1, NULL, NULL),
('ramjoker1208@gmail.c', 2, 'Finland', 1, NULL, NULL),
('ramjoker1208@gmail.c', 1, 'Sherlock Holmes', 1, NULL, NULL),
('ramjoker1208@gmail.c', 2, 'Finland', 1, NULL, NULL),
('ramjoker1208@gmail.c', 3, 'Mercury', 0, NULL, NULL),
('ramjoker1208@gmail.c', 4, 'Delta', 1, NULL, NULL),
('ramjoker1208@gmail.c', 1, 'Sherlock Holmes', 1, NULL, NULL),
('ramjoker1208@gmail.c', 2, 'Finland', 1, NULL, NULL),
('ramjoker1208@gmail.c', 3, 'Mercury', 0, NULL, NULL),
('ramjoker1208@gmail.c', 4, 'Delta', 1, NULL, NULL),
('ramjoker1208@gmail.c', 1, 'Sherlock Holmes', 1, NULL, NULL),
('ramjoker1208@gmail.c', 2, 'Finland', 1, NULL, NULL),
('ramjoker1208@gmail.c', 3, 'Mercury', 0, NULL, NULL),
('ramjoker1208@gmail.c', 4, 'Delta', 1, NULL, NULL),
('ramjoker1208@gmail.c', 1, 'Iron Man', 0, NULL, NULL),
('ramjoker1208@gmail.c', 2, 'Finland', 1, NULL, NULL),
('ramjoker1208@gmail.c', 3, 'Mercury', 0, NULL, NULL),
('ramjoker1208@gmail.c', 4, 'Gamma', 0, NULL, NULL),
('ramjoker1208@gmail.c', 1, 'Iron Man', 0, NULL, NULL),
('ramjoker1208@gmail.c', 2, 'Finland', 1, NULL, NULL),
('ramjoker1208@gmail.c', 3, 'Mercury', 0, NULL, NULL),
('ramjoker1208@gmail.c', 4, 'Gamma', 0, NULL, NULL),
('ramjoker1208@gmail.c', 1, 'Iron Man', 0, NULL, NULL),
('ramjoker1208@gmail.c', 2, 'Finland', 1, NULL, NULL),
('ramjoker1208@gmail.c', 3, 'Mercury', 0, NULL, NULL),
('ramjoker1208@gmail.c', 4, 'Gamma', 0, NULL, NULL),
('ramjoker1208@gmail.c', 1, 'Iron Man', 0, NULL, NULL),
('ramjoker1208@gmail.c', 2, 'Finland', 1, NULL, NULL),
('ramjoker1208@gmail.c', 3, 'Mercury', 0, NULL, NULL),
('ramjoker1208@gmail.c', 4, 'Gamma', 0, NULL, NULL),
('ramjoker1208@gmail.c', 1, 'Iron Man', 0, NULL, NULL),
('ramjoker1208@gmail.c', 2, 'Finland', 1, NULL, NULL),
('ramjoker1208@gmail.c', 3, 'Mercury', 0, NULL, NULL),
('ramjoker1208@gmail.c', 4, 'Gamma', 0, NULL, NULL),
('ramjoker1208@gmail.c', 1, 'Iron Man', 0, NULL, NULL),
('ramjoker1208@gmail.c', 2, 'Finland', 1, NULL, NULL),
('ramjoker1208@gmail.c', 3, 'Mercury', 0, NULL, NULL),
('ramjoker1208@gmail.c', 4, 'Gamma', 0, NULL, NULL),
('ramjoker1208@gmail.c', 1, 'Iron Man', 0, NULL, NULL),
('ramjoker1208@gmail.c', 2, 'Finland', 1, NULL, NULL),
('ramjoker1208@gmail.c', 3, 'Mercury', 0, NULL, NULL),
('ramjoker1208@gmail.c', 4, 'Gamma', 0, NULL, NULL),
('ramjoker1208@gmail.c', 1, 'Iron Man', 0, NULL, NULL),
('ramjoker1208@gmail.c', 2, 'Finland', 1, NULL, NULL),
('ramjoker1208@gmail.c', 3, 'Mercury', 0, NULL, NULL),
('ramjoker1208@gmail.c', 4, 'Delta', 1, NULL, NULL),
('kumar@gmail.com', 1, ' func', 0, NULL, NULL),
('kumar@gmail.com', 2, '( )', 0, NULL, NULL),
('kumar@gmail.com', 3, '.py', 0, NULL, NULL),
('kumar@gmail.com', 4, 'C', 0, NULL, NULL),
('kumar@gmail.com', 5, '12_hello', 0, NULL, NULL),
('kumar@gmail.com', 6, 'False', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `login_sessions`
--

CREATE TABLE IF NOT EXISTS `login_sessions` (
  `ic_number` varchar(20) NOT NULL,
  `batch_code` varchar(20) NOT NULL,
  `session_id` varchar(50) NOT NULL,
  PRIMARY KEY (`ic_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `login_sessions`
--

INSERT INTO `login_sessions` (`ic_number`, `batch_code`, `session_id`) VALUES
('G6357282P', '19674', '2bfbn1khkgopv60u6tdjgnd6c3'),
('G7938085M', '19674', 'db6gs6ingrtjo0ia1nk58juub5');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE IF NOT EXISTS `questions` (
  `qid` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL,
  `ans_id` int(11) NOT NULL,
  PRIMARY KEY (`qid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`qid`, `question`, `ans_id`) VALUES
(1, 'Which of the following brackets are used in python to create a list?', 46),
(2, 'Which of the following is the correct extension of a python file?', 49),
(3, 'In which language python is written?', 55),
(4, 'Which of the following is invalid variable?', 59),
(5, ' Is python identifiers case sensitive?', 62),
(6, 'Which of the following is not the part of python programming?', 65),
(7, 'Which function is used to get the version of python?', 70),
(8, 'Which of the following is the built in function in python?', 76),
(9, ' List in Python is ................in nature.', 78),
(10, 'What is the correct syntax for defining a function in Python?', 83);

-- --------------------------------------------------------

--
-- Table structure for table `quiz_topics`
--

CREATE TABLE IF NOT EXISTS `quiz_topics` (
  `quiz_id` int(11) NOT NULL AUTO_INCREMENT,
  `quiz_topic` text NOT NULL,
  `batch_code` varchar(20) NOT NULL,
  `quiz_link` varchar(255) NOT NULL,
  `num_questions` int(11) NOT NULL,
  `total_marks` int(11) NOT NULL,
  `quiz_date` date NOT NULL,
  `total_time` time DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `quiz_time` time DEFAULT NULL,
  PRIMARY KEY (`quiz_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `quiz_topics`
--

INSERT INTO `quiz_topics` (`quiz_id`, `quiz_topic`, `batch_code`, `quiz_link`, `num_questions`, `total_marks`, `quiz_date`, `total_time`, `created_at`, `quiz_time`) VALUES
(3, 'general quiz', '19674', 'https://forms.office.com/Pages/ShareFormPage.aspx?id=DQSIkWdsW0yxEjajBLZtrQAAAAAAAAAAAAO__R2GXyJUMFhVTTdPUTcwNUMzVUI4NVJVQjhWWEIzTy4u&sharetoken=lsThMloso19ARJtwM0JE ', 4, 4, '2024-04-19', '01:00:00', '2024-03-31 19:01:34', '13:15:00'),
(1, 'general quiz', '19674', 'https://forms.office.com/Pages/ShareFormPage.aspx?id=DQSIkWdsW0yxEjajBLZtrQAAAAAAAAAAAAO__R2GXyJUMFhVTTdPUTcwNUMzVUI4NVJVQjhWWEIzTy4u&sharetoken=lsThMloso19ARJtwM0JE ', 4, 4, '2024-04-19', '01:00:00', '2024-03-31 19:01:34', '13:15:00');

-- --------------------------------------------------------

--
-- Table structure for table `score`
--

CREATE TABLE IF NOT EXISTS `score` (
  `email` varchar(50) NOT NULL,
  `total` int(10) NOT NULL,
  `grade` varchar(10) NOT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `score`
--

INSERT INTO `score` (`email`, `total`, `grade`) VALUES
('kumar@gmail.com', 0, 'fail'),
('ramjoker1208@gmail.com', 2, 'fail');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE IF NOT EXISTS `teachers` (
  `t_id` int(11) NOT NULL AUTO_INCREMENT,
  `t_name` varchar(20) NOT NULL,
  `t_email` varchar(30) NOT NULL,
  `t_mobile` bigint(10) NOT NULL,
  `t_pass` varchar(20) NOT NULL,
  PRIMARY KEY (`t_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`t_id`, `t_name`, `t_email`, `t_mobile`, `t_pass`) VALUES
(2, 'ramkumar', 'ramjoker1208@gmail.com', 9003943238, 'ramkumar');

-- --------------------------------------------------------

--
-- Table structure for table `timer`
--

CREATE TABLE IF NOT EXISTS `timer` (
  `duration` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `timer`
--

INSERT INTO `timer` (`duration`) VALUES
('00:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_dob` date NOT NULL,
  `user_pass` varchar(30) NOT NULL,
  `ic_number` varchar(20) NOT NULL,
  `batch_code` varchar(20) NOT NULL,
  `login` int(11) DEFAULT '0',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `mobile`, `user_email`, `user_dob`, `user_pass`, `ic_number`, `batch_code`, `login`) VALUES
(1, 'ramkumar', '9003943238', 'ramjoker1208@gmail.com', '2002-08-12', 'ramkumar', '', '', 0),
(5, 'kumar', '9003943238', 'kumar@gmail.com', '2002-08-12', 'ramkumar', 'G6357282P', '19674', 0),
(6, 'ram', '9003943238', 'ram@gmail.com', '2002-08-12', 'ramkumar', 'G7938085M', '19674', 1);
